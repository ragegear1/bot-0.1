{
  'How to Analyze Crypto?': 'VALUE',
  'Forks Explained': 'GO GET',
  'Secure your Crypto!': 'BEST PROJECT EVER',
  'Navigating Crypto': 'HEYBLUM',
  'What are Telegram Mini Apps?': 'CRYPTOBLUM',
  'Say No to Rug Pull!': 'SUPERBLUM'
}
